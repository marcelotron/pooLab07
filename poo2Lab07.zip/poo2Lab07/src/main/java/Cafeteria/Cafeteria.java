package Cafeteria;

abstract class Cafeteria {

    public void preparaPedido() {
        aqueceAgua();
        preparaBebida();
        colocarXicara();
        AdicionaCondimentos();

    }

    public void colocarXicara() {
         System.out.println("Colocando na xícara");

    }

    public void aqueceAgua() {
         System.out.println("Aquecendo a água");

    }

    abstract void preparaBebida();
    abstract void AdicionaCondimentos();

}
 
