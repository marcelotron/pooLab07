package Cafeteria;

public class Cafe extends Cafeteria {

    @Override
    void preparaBebida() {
        System.out.println("Preparando o café");

    }

    @Override
    void AdicionaCondimentos() {
        System.out.println("Adicionando açúcar e leite");
    }

}
