
package Cafeteria;


public class Cha extends Cafeteria {

    @Override
    void preparaBebida() {
         System.out.println("Preparando o chá");
    }

    @Override
    void AdicionaCondimentos() {
          System.out.println("Adicionando limão");
    }
    
}
