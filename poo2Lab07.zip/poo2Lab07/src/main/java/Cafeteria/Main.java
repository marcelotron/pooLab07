
package Cafeteria;


public class Main {
    public static void main(String[] args){
        Cafeteria cafe=new Cafe();
        cafe.preparaPedido();
        
        Cafeteria cappucino=new Cappucino();
        cappucino.preparaPedido();
        
        Cafeteria cha=new Cha();
        cha.preparaPedido();
        
        
        
    }
}
