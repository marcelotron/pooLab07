
package Cafeteria;


public class Cappucino extends Cafeteria {

    @Override
    void preparaBebida() {
        System.out.println("Preparando o café com leite");
    }

    @Override
    void AdicionaCondimentos() {
          System.out.println("Adicionando açúcar, leite e canela");
    }
    
}
