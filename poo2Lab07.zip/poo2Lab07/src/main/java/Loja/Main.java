
package Loja;


public class Main {
     public static void main(String[] args) {
        Pedido pedidoOnline = new PedidoOnline();
        pedidoOnline.processarPedido(2, 50.0, "cartão de crédito");

        Pedido pedidoLoja = new PedidoLoja();
        pedidoLoja.processarPedido(1, 100.0, "dinheiro");

        Pedido pedidoCripto = new PedidoCripto();
        pedidoCripto.processarPedido(3, 200.0, "Bitcoin");
    }
}
