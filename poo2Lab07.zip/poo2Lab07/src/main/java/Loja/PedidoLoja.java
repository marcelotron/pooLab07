
package Loja;


public class PedidoLoja extends Pedido {

    void processarPagamento(int quantidade, double valorItem, String formaPagamento) {
        double total = quantidade * valorItem;
        System.out.println("Processando pagamento na loja de " + total + " via " + formaPagamento);
    }

    void decidirEntrega() {
        System.out.println("Cliente irá retirar na loja");
    }
}
