
package Loja;


public class PedidoCripto extends Pedido {

    void processarPagamento(int quantidade, double valorItem, String formaPagamento) {
        double total = quantidade * valorItem;
        System.out.println("Processando pagamento de " + total + " via " + formaPagamento);
    }

    void decidirEntrega() {
        System.out.println("Entrega será feita por drone");
    }
}