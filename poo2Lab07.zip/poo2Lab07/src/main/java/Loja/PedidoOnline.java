
package Loja;


public class PedidoOnline extends Pedido {

    void processarPagamento(int quantidade, double valorItem, String formaPagamento) {
        double total = quantidade * valorItem;
        System.out.println("Processando pagamento online de " + total + " via " + formaPagamento);
    }

    void decidirEntrega() {
        System.out.println("Entrega será feita por correio");
    }
}
