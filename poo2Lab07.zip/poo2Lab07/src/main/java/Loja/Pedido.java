package Loja;

public abstract class Pedido {

    void processarPedido(int quantidade, double valorItem, String formaPagamento) {
        processarPagamento(quantidade, valorItem, formaPagamento);
        decidirEntrega();
    }

    abstract void processarPagamento(int quantidade, double valorItem, String formaPagamento);

    abstract void decidirEntrega();
}
