
package com.mycompany.poo2lab07;


public class Poo2Lab07 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
